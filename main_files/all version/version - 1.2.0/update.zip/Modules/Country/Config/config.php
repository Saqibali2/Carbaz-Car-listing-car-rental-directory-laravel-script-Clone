<?php

return [
    'name' => 'Country'
];
