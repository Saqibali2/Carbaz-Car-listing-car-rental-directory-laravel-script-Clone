<?php
 return array (
  
  'Country List' => 'Country List',
  'Manage Location' => 'Manage Location',
  'Create Country' => 'Create Country',
  'Edit Country' => 'Edit Country',
  'Country Name' => 'Country Name',
  'Select Country' => 'Select Country',
  'Country is required' => 'Country is required',

);
 ?>
